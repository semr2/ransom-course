(function () {
  var TOTAL_SLIDES = 6; // 0..5
  var currentSlide = 0;

  /* ---------- Scenario drill data ---------- */
  var scenarios = [
    {
      title: "Password Reset Request",
      from: "IT Support &lt;it-helpdesk@corp-secur1ty-portal.com&gt;",
      to: "you@yourcompany.com",
      subject: "URGENT: Your mailbox will be suspended in 2 hours",
      body: "Dear User,\n\nOur system detected unusual activity on your account. You must verify your identity within the next 2 hours or your mailbox will be permanently deleted.\n\nPlease click the link below and sign in with your current password to confirm your identity:\n\nhttps://corp-secure-loginportal.net/verify?user=you\n\nThank you,\nThe IT Team",
      isPhishing: true,
      verdict: "This is a phishing attempt.",
      action: "Don't click the link or enter your password. Report it to IT/Security and delete it.",
      insights: [
        "Sender domain is a look-alike (\"corp-secur1ty-portal.com\"), not your real company domain",
        "Manufactured urgency (\"2 hours\") to make you act without thinking",
        "Asks you to \"confirm your identity\" by entering your password on an external link",
        "Link domain doesn't match your organization's real domain"
      ]
    },
    {
      title: "Calendar Invite From a Coworker",
      from: "Priya Nair &lt;priya.nair@yourcompany.com&gt;",
      to: "you@yourcompany.com",
      subject: "Re: Q3 planning — quick sync?",
      body: "Hi,\n\nCould we grab 20 minutes this week to go over the Q3 roadmap before Thursday's meeting? I've sent a calendar invite for Wednesday at 2pm — let me know if that doesn't work.\n\nThanks,\nPriya",
      isPhishing: false,
      verdict: "This one looks legitimate.",
      action: "No special action needed — though it's always fine to confirm details in chat if anything ever feels off.",
      insights: [
        "Sender address matches your real company domain",
        "No urgency, threats, or requests for credentials/payment",
        "References a specific, plausible, ongoing work topic",
        "Doesn't ask you to click a suspicious link or download anything unexpected"
      ]
    },
    {
      title: "Gift Card Request From \"The CEO\"",
      from: "Alex Turner &lt;alex.turner@yourcompany.co&gt;",
      to: "you@yourcompany.com",
      subject: "Quick favor (urgent)",
      body: "Hey,\n\nI'm stuck in back-to-back meetings and need your help. Can you pick up 5 x $100 gift cards for a client gift? Send me the codes as soon as you get them — I'll pay you back. Please don't mention this to anyone else on the team yet, it's a surprise.\n\nThanks,\nAlex\nCEO",
      isPhishing: true,
      verdict: "This is a phishing / impersonation (BEC) attempt.",
      action: "Don't purchase anything or reply. Verify the request by contacting the person directly through a known phone number or in person — never through the email itself.",
      insights: [
        "Sender domain is subtly wrong (\".co\" instead of your real \".com\")",
        "Urgency plus secrecy (\"don't mention this to anyone\") to prevent verification",
        "Requests gift cards — a classic sign of a business email compromise (BEC) scam",
        "Pressure to act immediately without normal approval steps"
      ]
    },
    {
      title: "Shared Document Notification",
      from: "SharePoint &lt;no-reply@sharepointonline.com&gt;",
      to: "you@yourcompany.com",
      subject: "\"Q3_Budget_Review.xlsx\" has been shared with you",
      body: "Jordan Lee has shared a document with you.\n\nQ3_Budget_Review.xlsx\n\nOpen the document using your organization's sign-in. This link will expire in 7 days.",
      isPhishing: false,
      verdict: "This one looks legitimate.",
      action: "Still worth a quick habit check: hover the link to confirm it points to your real organization's domain before signing in.",
      insights: [
        "Sender domain matches the real SharePoint notification domain",
        "No artificial urgency or threats",
        "References a specific, named coworker and document",
        "Standard organizational sign-in flow, not a request to type a password into the email itself"
      ]
    }
  ];

  var scenarioAnswers = new Array(scenarios.length).fill(null);
  var scenarioIndex = 0;

  function renderScenario(i) {
    var s = scenarios[i];
    var container = document.getElementById("scenarioContainer");
    var pct = Math.round((i / scenarios.length) * 100);

    container.innerHTML =
      '<div class="scenario-single">' +
        '<div class="scenario-progress-bar"><div class="progress-fill" style="width:' + pct + '%"></div></div>' +
        '<div class="scenario-number">Scenario ' + (i + 1) + ' of ' + scenarios.length + '</div>' +
        '<div class="scenario-title">' + s.title + '</div>' +
        '<div class="scenario-email-box">' +
          '<div class="email-full-view">' +
            '<div class="email-header-section">' +
              '<div class="email-row"><span class="email-label">From</span><span class="email-value">' + s.from + '</span></div>' +
              '<div class="email-row"><span class="email-label">To</span><span class="email-value">' + s.to + '</span></div>' +
              '<div class="email-row"><span class="email-label">Subject</span><span class="email-value email-subject">' + s.subject + '</span></div>' +
            '</div>' +
            '<div class="email-body-section">' +
              '<div class="email-body-label">Message</div>' +
              '<div class="email-body-content">' + s.body + '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div class="scenario-question">' +
          '<div class="question-text">Is this message safe, or a phishing / impersonation attempt?</div>' +
          '<div class="choice-buttons" id="choiceButtons">' +
            '<button class="choice-btn choice-btn--danger" data-choice="phishing">🚩 Phishing</button>' +
            '<button class="choice-btn choice-btn--safe" data-choice="safe">✅ Legitimate</button>' +
          '</div>' +
        '</div>' +
        '<div class="scenario-result" id="scenarioResult" hidden></div>' +
        '<div class="scenario-nav">' +
          '<button class="nav-btn" id="scenarioBackBtn"' + (i === 0 ? ' disabled' : '') + '>Back</button>' +
          '<button class="nav-btn nav-btn--primary" id="scenarioNextBtn" disabled>' +
            (i === scenarios.length - 1 ? "Finish Drill" : "Next Scenario") +
          '</button>' +
        '</div>' +
      '</div>';

    document.querySelectorAll('#choiceButtons .choice-btn').forEach(function (btn) {
      btn.addEventListener("click", function () { answerScenario(i, btn.dataset.choice); });
    });
    document.getElementById("scenarioBackBtn").addEventListener("click", function () {
      if (i > 0) { scenarioIndex = i - 1; renderScenario(scenarioIndex); }
    });
    document.getElementById("scenarioNextBtn").addEventListener("click", function () {
      if (i < scenarios.length - 1) {
        scenarioIndex = i + 1;
        renderScenario(scenarioIndex);
      } else {
        goToSlide(4);
      }
    });

    // Restore a previous answer for this scenario, if any.
    if (scenarioAnswers[i] !== null) {
      showScenarioFeedback(i, scenarioAnswers[i]);
    }
  }

  function answerScenario(i, choice) {
    if (scenarioAnswers[i] !== null) return; // already answered
    scenarioAnswers[i] = choice;
    showScenarioFeedback(i, choice);
  }

  function showScenarioFeedback(i, choice) {
    var s = scenarios[i];
    var chosePhishing = choice === "phishing";
    var isCorrect = chosePhishing === s.isPhishing;

    document.querySelectorAll('#choiceButtons .choice-btn').forEach(function (btn) {
      btn.disabled = true;
      if (btn.dataset.choice === choice) btn.style.outline = "2px solid var(--text-primary)";
    });

    var resultEl = document.getElementById("scenarioResult");
    resultEl.hidden = false;
    resultEl.className = "scenario-result " + (isCorrect ? "result-correct" : "result-incorrect");
    resultEl.innerHTML =
      '<div class="result-header">' + (isCorrect ? "Correct" : "Not quite") + '</div>' +
      '<div class="result-verdict">' + s.verdict + '</div>' +
      '<div class="result-action"><strong>What to do</strong>' + s.action + '</div>' +
      '<div class="result-insights"><strong>Why</strong><ul>' +
        s.insights.map(function (line) { return "<li>" + line + "</li>"; }).join("") +
      '</ul></div>';

    document.getElementById("scenarioNextBtn").disabled = false;
  }

  /* ---------- Slide navigation ---------- */
  function updateProgress() {
    var pct = Math.round((currentSlide / (TOTAL_SLIDES - 1)) * 100);
    document.getElementById("progressFill").style.width = pct + "%";
  }

  function goToSlide(n) {
    document.querySelectorAll(".slide").forEach(function (s) { s.classList.remove("active"); });
    var target = document.querySelector('.slide[data-slide="' + n + '"]');
    if (target) target.classList.add("active");
    currentSlide = n;
    updateProgress();
    window.scrollTo(0, 0);

    if (n === 3 && !document.getElementById("scenarioContainer").hasChildNodes()) {
      renderScenario(scenarioIndex);
    }
    if (n === 5) {
      showResults();
    }
  }

  function startModule() {
    // SCORM initialization hook — fires when the learner actually starts.
    if (typeof scorm !== "undefined") { scorm.init(); }
    goToSlide(1);
  }

  function scoreDrill() {
    var correct = 0;
    scenarios.forEach(function (s, i) {
      var choice = scenarioAnswers[i];
      if (choice !== null && (choice === "phishing") === s.isPhishing) correct++;
    });
    return correct;
  }

  function showResults() {
    var score = scoreDrill();
    var total = scenarios.length;
    var passed = score >= 3; // 3 of 4 = 75% mastery

    document.getElementById("resultLine").textContent =
      "You correctly identified " + score + " out of " + total + " scenarios.";

    var banner = document.getElementById("summaryBanner");
    banner.textContent = passed
      ? "Nice work — you're ready to spot phishing and impersonation attempts before they cause harm."
      : "Review the lesson sections and retake the drill — aim for at least 3 out of 4 correct.";
    banner.style.borderColor = passed ? "rgba(34,197,94,0.35)" : "rgba(239,68,68,0.35)";
    banner.style.color = passed ? "#d6ffe9" : "#ffd9d6";

    // SCORM completion hook — reports score and pass/fail status to the LMS.
    if (typeof scorm !== "undefined" && scorm.isActive) {
      scorm.setScore(score, total, 0);
      var status = passed ? "passed" : "failed";
      scorm.complete(status);
    }
  }

  function retryDrill() {
    scenarioAnswers = new Array(scenarios.length).fill(null);
    scenarioIndex = 0;
    document.getElementById("scenarioContainer").innerHTML = "";
    goToSlide(3);
  }

  document.addEventListener("DOMContentLoaded", function () {
    updateProgress();
    document.getElementById("startBtn").addEventListener("click", startModule);
    document.getElementById("retryBtn").addEventListener("click", retryDrill);

    document.querySelectorAll('[data-nav="next"]').forEach(function (btn) {
      btn.addEventListener("click", function () { goToSlide(currentSlide + 1); });
    });
    document.querySelectorAll('[data-nav="prev"]').forEach(function (btn) {
      btn.addEventListener("click", function () { goToSlide(currentSlide - 1); });
    });
  });
})();
