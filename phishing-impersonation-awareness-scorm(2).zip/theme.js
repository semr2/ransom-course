/**
 * theme.js
 * Minimal theme bootstrap. Ensures the dark theme class is present and
 * (defensively) initializes an icon library if one happens to be loaded,
 * without requiring any external dependency to function.
 */
(function () {
  document.addEventListener("DOMContentLoaded", function () {
    if (!document.body.classList.contains("default-dark")) {
      document.body.classList.add("default-dark");
    }
    // Safe no-op unless an icon library (e.g. lucide) is present locally.
    if (typeof window.lucide !== "undefined" && typeof window.lucide.createIcons === "function") {
      try { window.lucide.createIcons(); } catch (e) { /* ignore */ }
    }
  });
})();
