/**
 * scorm-wrapper.js
 * Minimal, self-contained SCORM 1.2 / SCORM 2004 runtime wrapper.
 * No external/remote dependencies. Auto-detects whichever LMS API
 * (SCORM 1.2 "API" or SCORM 2004 "API_1484_11") is present in the
 * window/frame hierarchy and normalizes calls against it.
 */
(function (global) {
  var API = null;
  var apiVersion = null; // "1.2" or "2004"
  var initialized = false;

  function findAPI(win) {
    var attempts = 0;
    while (win && attempts < 500) {
      if (win.API_1484_11) { return { api: win.API_1484_11, version: "2004" }; }
      if (win.API) { return { api: win.API, version: "1.2" }; }
      if (win.parent && win.parent !== win) {
        win = win.parent;
      } else {
        break;
      }
      attempts++;
    }
    return null;
  }

  function locateAPI() {
    var found = findAPI(global);
    if (!found && global.opener) {
      found = findAPI(global.opener);
    }
    if (found) {
      API = found.api;
      apiVersion = found.version;
    }
    return !!found;
  }

  function call(method1p2, method2004, args) {
    if (!API) return null;
    var method = apiVersion === "2004" ? method2004 : method1p2;
    try {
      return API[method].apply(API, args || []);
    } catch (e) {
      return null;
    }
  }

  var scorm = {
    isActive: false,

    init: function () {
      if (initialized) return true;
      if (!locateAPI()) {
        // No LMS present (e.g. previewing locally) - fail gracefully.
        this.isActive = false;
        return false;
      }
      var result = call("LMSInitialize", "Initialize", [""]);
      initialized = (result === "true" || result === true);
      this.isActive = initialized;
      if (initialized) {
        // Mark incomplete until the learner finishes.
        if (apiVersion === "2004") {
          call(null, "SetValue", ["cmi.completion_status", "incomplete"]);
        } else {
          call("LMSSetValue", null, ["cmi.core.lesson_status", "incomplete"]);
        }
        this.commit();
      }
      return initialized;
    },

    setScore: function (raw, max, min) {
      if (!this.isActive) return;
      max = (typeof max === "number") ? max : 100;
      min = (typeof min === "number") ? min : 0;
      if (apiVersion === "2004") {
        call(null, "SetValue", ["cmi.score.raw", String(raw)]);
        call(null, "SetValue", ["cmi.score.max", String(max)]);
        call(null, "SetValue", ["cmi.score.min", String(min)]);
        call(null, "SetValue", ["cmi.score.scaled", String(max > 0 ? raw / max : 0)]);
      } else {
        call("LMSSetValue", null, ["cmi.core.score.raw", String(raw)]);
        call("LMSSetValue", null, ["cmi.core.score.max", String(max)]);
        call("LMSSetValue", null, ["cmi.core.score.min", String(min)]);
      }
      this.commit();
    },

    complete: function (status) {
      // status: "passed" | "failed" | "completed" | "incomplete"
      if (!this.isActive) return;
      if (apiVersion === "2004") {
        call(null, "SetValue", ["cmi.completion_status",
          (status === "passed" || status === "failed") ? "completed" : status]);
        if (status === "passed" || status === "failed") {
          call(null, "SetValue", ["cmi.success_status", status]);
        }
      } else {
        // SCORM 1.2 overloads lesson_status with pass/fail/completed.
        call("LMSSetValue", null, ["cmi.core.lesson_status", status]);
      }
      this.commit();
    },

    commit: function () {
      call("LMSCommit", "Commit", [""]);
    },

    terminate: function () {
      if (!this.isActive) return;
      this.commit();
      call("LMSFinish", "Terminate", [""]);
      this.isActive = false;
      initialized = false;
    }
  };

  global.scorm = scorm;

  global.addEventListener("beforeunload", function () {
    if (scorm.isActive) scorm.terminate();
  });
})(window);
